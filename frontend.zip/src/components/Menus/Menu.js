import React from 'react';
import './menu.css';
import imageSource from './photo.jpg';
import { FcAbout, FcHome, FcReading, FcVideoProjector, FcBusinessContact } from 'react-icons/fc'
import { GiLaptop } from 'react-icons/gi'
import { RiSettings2Fill } from 'react-icons/ri'
import Home from '../../pages/Home/Home';


const Menu = (props) => {
    const { toggle } = props;
    return (
        <>
            {toggle ? (
                <>
                    {/* <div className="navbar-photo">
                        <img src={imageSource} alt="photo" />
                    </div> */}
                    <div className="nav-items">
                        <div className="nav-item">
                            <div className="nav-link"><FcHome /> Home</div>
                            <hr />
                        </div>
                        <div className="nav-item">
                            <div className="nav-link"><FcAbout /> About</div>
                        </div>
                        <hr />
                        <div className="nav-item">
                            <div className="nav-link"><GiLaptop /> Work Experience</div>
                        </div>
                        <hr />
                        <div className="nav-item">
                            <div className="nav-link"><RiSettings2Fill /> Tech Stack</div>
                        </div>
                        <hr />
                        <div className="nav-item">
                            <div className="nav-link"><FcVideoProjector /> Projects</div>
                        </div>
                        <hr />
                        <div className="nav-item">
                            <div className="nav-link"><FcReading /> Education </div>
                        </div>
                        <hr />
                        <div className="nav-item">
                            <div className="nav-link"><FcBusinessContact /> Contact</div>
                        </div>
                        <hr />
                    </div>
                </>
            ) : (
                <>

                    <div className="nav-items">
                        <div className="nav-item">
                            <div className="nav-link"><FcHome title="Home" /></div>
                        </div>
                        <div className="nav-item">
                            <div className="nav-link"><FcAbout title="About" /></div>
                        </div>
                        <div className="nav-item">
                            <div className="nav-link"><GiLaptop title="Work Experience" /></div>
                        </div>
                        <div className="nav-item">
                            <div className="nav-link"><RiSettings2Fill title="Tech Stack" /></div>
                        </div>
                        <div className="nav-item">
                            <div className="nav-link"><FcVideoProjector title="Projects" /></div>
                        </div>
                        <div className="nav-item">
                            <div className="nav-link"><FcReading title="Education" /></div>
                        </div>
                        <div className="nav-item">
                            <div className="nav-link"><FcBusinessContact title="Contact" /></div>
                        </div>
                    </div>
                </>
            )}

        </>
    );
};

export default Menu;
